
public class UserTotalVisitor implements Visitor {

    private int count = 0;

    @Override
    public int visit(Component component) {   
        if (component instanceof User) {
            count++;
        }else{
            for (Component child : component.children) {
                visit(child);
            }
        }
        return count;
    }

}
