
import java.util.ArrayList;
import java.util.List;

public class UserValidationVisitor implements Visitor {

    List<String> ids = new ArrayList<>();

    @Override
    public void visit(Component component) {
        if (component instanceof User) {
            ids.add(component.id);
        }else{
            ids.add(component.id);
            for (Component child : component.children) {
                visit(child);
            }
        }
    }

    public List<String> checkUnique() {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < ids.size(); i++) {
            for (int j = i + 1; j < ids.size(); j++) {
                if (ids.get(i).equals(ids.get(j))) {
                    list.add(ids.get(i) + " is not unique");
                }
            }

        }
        return list;
    }

    public List<String> checkSpaces() {
        List<String> list = new ArrayList<>();
        for (int i = 0; i < ids.size(); i++) {
            if(ids.get(i).contains(" ")){
                 list.add(ids.get(i) + " contains space");
            }
        }
        return list;
    }
}
