
import java.util.List;

public class TweetVisitor implements Visitor {

    private int tweets = 0;


    @Override
    public int visit(Component component) {
        List<Tweet> userTweets = component.getNewsFeed();
        tweets += userTweets.size();
        return tweets;
    }
}
