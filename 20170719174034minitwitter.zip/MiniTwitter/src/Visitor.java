
public interface Visitor {

    public void visit(Component user);
}
