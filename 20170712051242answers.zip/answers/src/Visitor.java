
public interface Visitor {

    public int visit(Component user);
}
