
public interface Visitable {

    public int accept(Visitor visitor);
}
